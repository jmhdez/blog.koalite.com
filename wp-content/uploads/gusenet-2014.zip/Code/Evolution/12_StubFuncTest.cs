﻿using System;
using System.Collections.Generic;
using System.Linq;
using Moq;
using NUnit.Framework;

namespace Evolution
{
    partial class SmsCampaign
    {
        public void Send(Action<Sms> sender)
        {
            startTime = DateTime.Now;

            foreach (var recipient in recipients)
            {
                var message = new Sms(recipient, content);

                sender(message);
            }

            endTime = DateTime.Now;
        }

    }

    [TestFixture]
    public class SendCampaignTest_Func
    {
        [Test]
        public void A_Message_Is_Sent_To_Each_Recipient()
        {
            var sent = new List<Sms>();

            var campaign = new SmsCampaign("Oferta especial", "123", "456", "789");

            campaign.Send(sent.Add);

            Assert.That(sent.All(x => x.Content == "Oferta especial"));

            Assert.That(sent.Any(x => x.Recipient == "123"));
            Assert.That(sent.Any(x => x.Recipient == "456"));
            Assert.That(sent.Any(x => x.Recipient == "789"));
        }
    }
}