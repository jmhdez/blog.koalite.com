﻿using NUnit.Framework;

namespace Evolution
{
    public class RealLifeSimpleTest
    {
        // Ver NopCommerce: SettingTestFixture
        // http://nopcommerce.codeplex.com/SourceControl/latest#src/Tests/Nop.Core.Tests/Domain/Configuration/SettingTestFixture.cs
    }
}
