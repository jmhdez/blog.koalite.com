﻿using System;
using NUnit.Framework;

namespace Evolution
{
    public class Person
    {
        public Person(string name, DateTime birthDate)
        {
            Name = name;
            BirthDate = birthDate;
        }

        public string Name { get; set; }
        public DateTime BirthDate { get; set; }
    }

    [TestFixture]
    public class PersonTests
    {
        [Test]
        public void Person_has_name_and_birthdate()
        {
            var person = new Person("Lucas", new DateTime(1987, 3, 8));

            Assert.That(person.Name, Is.EqualTo("Lucas"));
            Assert.That(person.BirthDate, Is.EqualTo(new DateTime(1987, 3, 8)));
        }

        [Test]
        public void Person_attributes_can_change()
        {
            var person = new Person("Lucas", new DateTime(1987, 3, 8));

            person.Name = "Marcelo";
            person.BirthDate = new DateTime(2001, 2, 7);

            Assert.That(person.Name, Is.EqualTo("Marcelo"));
            Assert.That(person.BirthDate, Is.EqualTo(new DateTime(2001, 2, 7)));
        }
    }
}
