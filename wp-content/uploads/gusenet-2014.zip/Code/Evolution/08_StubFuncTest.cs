﻿using System;
using Moq;
using NUnit.Framework;

namespace Evolution
{
    public partial class Registration
    {
        private readonly Student student;
        private readonly Course course;

        private decimal? price;
        private RegistrationStatus status;

        public Registration(Student student, Course course)
        {
            this.student = student;
            this.course = course;

            price = null;
            status = RegistrationStatus.Pending;
        }

        public void Confirm(IPricingService service)
        {
            if (status != RegistrationStatus.Pending)
                throw new InvalidOperationException("Registration is already confirmed");

            price = service.GetPrice(course, student);
            status = RegistrationStatus.Confirmed;
        }

        public decimal? Price { get { return price; } }
        public RegistrationStatus Status { get { return status; } }
    }


    public interface IPricingService
    {
        decimal GetPrice(Course course, Student student);
        decimal GetStandardPrice(Course course);
        decimal GetDiscountPrice(Course course);

        // ... un montón de métodos relacionado con el cálculo de precios
    }

    [TestFixture]
    public class RegistrationTest
    {
        [Test]
        public void Confirm_updates_price_and_status()
        {
            var student = new Student();
            var course = new Course();

            var registration = new Registration(student, course);

            var service = new Mock<IPricingService>();
            service.Setup(x => x.GetPrice(course, student)).Returns(42);

            registration.Confirm(service.Object);

            Assert.That(registration.Price, Is.EqualTo(42m));
            Assert.That(registration.Status, Is.EqualTo(RegistrationStatus.Confirmed));
        }
    }

    public enum RegistrationStatus
    {
        Pending,
        Confirmed
    }

    public class Student { }
    public class Course { }
}
