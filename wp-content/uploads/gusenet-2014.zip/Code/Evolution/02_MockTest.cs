﻿using System.Collections.Generic;
using Moq;
using NUnit.Framework;

namespace Evolution
{
    public class OrderService
    {
        private readonly IOrderRepository orderRepository;
        private readonly IMailSender mailSender;
        private readonly IWarehouseservice warehouseService;

        public OrderService(IOrderRepository orderRepository, IMailSender mailSender, IWarehouseservice warehouseService)
        {
            this.orderRepository = orderRepository;
            this.mailSender = mailSender;
            this.warehouseService = warehouseService;
        }

        public void ProcessPendingOrders()
        {
            var orders = orderRepository.FindPendingOrders();
            foreach (var order in orders)
            {
                mailSender.NotifyOrderCompleted(order);
                warehouseService.ReserveStock(order);

                order.Status = OrderStatus.Completed;
            }
        }
    }

    [TestFixture]
    public class OrderServiceTest
    {
        [Test]
        public void Process_Pending_Orders()
        {
            var orderRepository = new Mock<IOrderRepository>();
            var warehouseService = new Mock<IWarehouseservice>();
            var mailSender = new Mock<IMailSender>();

            var orderService = new OrderService(
                orderRepository.Object, 
                mailSender.Object,
                warehouseService.Object);

            var order1 = new Order {Id = 1};
            var order2 = new Order {Id = 2};
            var order3 = new Order {Id = 3};

            orderRepository.Setup(x => x.FindPendingOrders()).Returns(new[]
            {
              order1,
              order2, 
              order3
            });

            orderService.ProcessPendingOrders();

            Assert.That(order1.Status, Is.EqualTo(OrderStatus.Completed));
            Assert.That(order2.Status, Is.EqualTo(OrderStatus.Completed));
            Assert.That(order3.Status, Is.EqualTo(OrderStatus.Completed));

            warehouseService.Verify(x => x.ReserveStock(It.Is<Order>(o => o.Id == 1)));
            warehouseService.Verify(x => x.ReserveStock(It.Is<Order>(o => o.Id == 2)));
            warehouseService.Verify(x => x.ReserveStock(It.Is<Order>(o => o.Id == 3)));

            mailSender.Verify(x => x.NotifyOrderCompleted(It.Is<Order>(o => o.Id == 1)));
            mailSender.Verify(x => x.NotifyOrderCompleted(It.Is<Order>(o => o.Id == 2)));
            mailSender.Verify(x => x.NotifyOrderCompleted(It.Is<Order>(o => o.Id == 3)));
        }
    }


    public class Order
    {
        public Order()
        {
            Id = 0;
            Status = OrderStatus.Pending;
        }

        public int Id { get; set; }
        public OrderStatus Status { get; set; }
    }

    public enum OrderStatus
    {
        Pending, 
        Completed
    }

    public interface IWarehouseservice
    {
        void ReserveStock(Order order);
    }

    public interface IMailSender
    {
        void NotifyOrderCompleted(Order order);
    }

    public interface IOrderRepository
    {
        IEnumerable<Order> FindPendingOrders();
    }
}
