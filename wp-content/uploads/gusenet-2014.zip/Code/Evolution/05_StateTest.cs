﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Evolution
{
    public class ShoppingCart
    {
        private readonly List<Item> items = new List<Item>();

        public void Add(string product, decimal quantity, decimal price)
        {
            items.Add(new Item(product, quantity, price));
        }

        public decimal Total
        {
            get { return items.Sum(x => x.Quantity*x.Price); }
        }

        private class Item
        {
            public Item(string product, decimal quantity, decimal price)
            {
                Product = product;
                Quantity = quantity;
                Price = price;
            }

            public readonly string Product;
            public readonly decimal Quantity;
            public readonly decimal Price;
        }
    }

    [TestFixture]
    public class StateTest
    {
        [Test]
        public void Empty_Cart_Has_Total_Equals_To_Zero()
        {
            var cart = new ShoppingCart();

            Assert.That(cart.Total, Is.EqualTo(0));
        }

        [Test]
        public void Cart_With_One_Item_Has_Total_Equals_To_Item_Value()
        {
            var cart = new ShoppingCart();

            cart.Add("Camiseta", 2, 20m);

            Assert.That(cart.Total, Is.EqualTo(40m));
        }

        [Test]
        public void Cart_With_Many_Items_Sums_Item_Values()
        {
            var cart = new ShoppingCart();

            cart.Add("Camiseta", 2, 20m);
            cart.Add("Pantalón", 1, 50m);

            Assert.That(cart.Total, Is.EqualTo(90m));
        }
    }
}
