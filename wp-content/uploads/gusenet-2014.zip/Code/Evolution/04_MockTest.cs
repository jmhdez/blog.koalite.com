﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Evolution
{
    public class RealLifeMockTest
    {
        // Ver SocialGoal: AccountControllerTest::UserProfile
        // https://github.com/MarlabsInc/SocialGoal/blob/master/source/SocialGoal.Tests/Controllers/AccountControllerTest.cs#L192
    }
}
