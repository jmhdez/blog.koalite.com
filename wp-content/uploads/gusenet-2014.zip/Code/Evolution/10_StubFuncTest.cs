﻿using System;
using NUnit.Framework;

namespace Evolution
{
    public partial class Registration
    {
        // No puedo separar confirm en dos métodos, uno con dependencias y otro sin ellas, 
        // porque necesito garantizar que todo se hace a la vez

        public void Confirm(Func<Course, Student, decimal> priceCalculator)
        {
            if (status != RegistrationStatus.Pending)
                throw new InvalidOperationException("Registration is already confirmed");

            price = priceCalculator(course, student);
            status = RegistrationStatus.Confirmed;
        }
    }

    [TestFixture]
    public class RegistrationFuncTest
    {
        [Test]
        public void Final_Price_Is_Calculated_With_Func()
        {
            var student = new Student();
            var course = new Course();

            var registration = new Registration(student, course);

            registration.Confirm((c, s) => 42);

            Assert.That(registration.Price, Is.EqualTo(42m));
            Assert.That(registration.Status, Is.EqualTo(RegistrationStatus.Confirmed));
        }
    }
}
