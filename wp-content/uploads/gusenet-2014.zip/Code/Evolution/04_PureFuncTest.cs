﻿using NUnit.Framework;

namespace Evolution
{
    public class Calculator
    {
        public int Sum(int a, int b)
        {
            return a + b;
        }
    }

    [TestFixture]
    public class PureFuncTest
    {
        private readonly Calculator calculator = new Calculator();

        [Test]
        public void Sum_Positive_Numbers()
        {
            Assert.That(calculator.Sum(3, 2), Is.EqualTo(5));
        }
    }
}
