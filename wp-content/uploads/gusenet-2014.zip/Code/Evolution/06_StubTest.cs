﻿using System.Collections.Generic;
using System.Linq;
using Moq;
using NUnit.Framework;

namespace Evolution
{
    public class BlogService
    {
        private readonly IUserRepository userRepository;
        private readonly IPostRepository postRepository;

        public BlogService(IUserRepository userRepository, IPostRepository postRepository)
        {
            this.userRepository = userRepository;
            this.postRepository = postRepository;
        }

        public void PublishComment(int postId, int userId, string commentText)
        {
            var post = postRepository.FindById(postId);
            var user = userRepository.FindById(userId);

            var comment = new Comment(user, commentText);
            post.AddComment(comment);
        }
    }

    [TestFixture]
    public class PublishComment
    {
        [Test]
        public void Using_Mocks()
        {
            var userRepository = new Mock<IUserRepository>();
            var postRepository = new Mock<IPostRepository>();

            var service = new BlogService(userRepository.Object, postRepository.Object);

            var post = new Post();

            postRepository.Setup(x => x.FindById(19)).Returns(post);
            userRepository.Setup(x => x.FindById(4)).Returns(new User("Mariano"));

            service.PublishComment(19, 4, "Muy aburrido");

            var comment = post.GetComments().Single();

            Assert.That(comment.User.Name, Is.EqualTo("Mariano"));
            Assert.That(comment.Text, Is.EqualTo("Muy aburrido"));
        }
    }

    public interface IUserRepository
    {
        User FindById(int id);
    }

    public interface IPostRepository
    {
        Post FindById(int id);
    }

    public class User 
    {
        private readonly string name;

        public User(string name)
        {
            this.name = name;
        }

        public string Name
        {
            get { return name; }
        }
    }

    public class Comment
    {
        private readonly User user;
        private readonly string text;

        public Comment(User user, string text)
        {
            this.user = user;
            this.text = text;
        }

        public User User
        {
            get { return user; }
        }

        public string Text
        {
            get { return text; }
        }
    }

    public class Post
    {
        private readonly IList<Comment> comments = new List<Comment>();

        public void AddComment(Comment comment)
        {
            comments.Add(comment);
        }

        public IEnumerable<Comment> GetComments()
        {
            return comments;
        }
    }
}
