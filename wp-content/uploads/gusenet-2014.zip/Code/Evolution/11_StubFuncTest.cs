﻿using System;
using System.Collections.Generic;
using System.Linq;
using Moq;
using NUnit.Framework;

namespace Evolution
{
    public partial class SmsCampaign
    {
        private readonly IEnumerable<string> recipients;
        private readonly string content;

        private DateTime? startTime;
        private DateTime? endTime;

        public SmsCampaign(string content, params string[] recipients)
        {
            this.content = content;
            this.recipients = recipients.ToArray();
        }

        public void Send(ISmsSender sender)
        {
            startTime = DateTime.Now;

            foreach (var recipient in recipients)
            {
                var message = new Sms(recipient, content);

                sender.Send(message);
            }

            endTime = DateTime.Now;
        }
    }

    public class Sms
    {
        private readonly string recipient;
        private readonly string content;

        public Sms(string recipient, string content)
        {
            this.recipient = recipient;
            this.content = content;
        }

        public string Recipient
        {
            get { return recipient; }
        }

        public string Content
        {
            get { return content; }
        }
    }

    public interface ISmsSender
    {
        void Send(Sms sms);
    }

    [TestFixture]
    public class SendCampaignTest
    {
        [Test]
        public void A_Message_Is_Sent_To_Each_Recipient()
        {
            var sender = new Mock<ISmsSender>();

            var campaign = new SmsCampaign("Oferta especial", "123", "456", "789");

            campaign.Send(sender.Object);

            sender.Verify(x => x.Send(It.Is<Sms>(sms => sms.Content == "Oferta especial"
                                                        && sms.Recipient == "123")));

            sender.Verify(x => x.Send(It.Is<Sms>(sms => sms.Content == "Oferta especial"
                                                        && sms.Recipient == "456")));

            sender.Verify(x => x.Send(It.Is<Sms>(sms => sms.Content == "Oferta especial"
                                                        && sms.Recipient == "789")));
        }
    }
}