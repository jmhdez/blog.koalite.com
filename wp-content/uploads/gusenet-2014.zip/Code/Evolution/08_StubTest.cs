﻿using System.Linq;
using NUnit.Framework;

namespace Evolution
{
    public class BlogService2
    {
        private readonly IUserRepository userRepository;
        private readonly IPostRepository postRepository;

        public BlogService2(IUserRepository userRepository, IPostRepository postRepository)
        {
            this.userRepository = userRepository;
            this.postRepository = postRepository;
        }

        public void PublishComment(int postId, int userId, string commentText)
        {
            var post = postRepository.FindById(postId);
            var user = userRepository.FindById(userId);

            PublishComment(post, user, commentText);
        }

        public static void PublishComment(Post post, User user, string commentText)
        {
            var comment = new Comment(user, commentText);
            post.AddComment(comment);
        }
    }

    [TestFixture]
    public class PublishComment_Alt
    {
        [Test]
        public void Testing_Only_State()
        {
            var post = new Post();
            var user = new User("Mariano");

            BlogService2.PublishComment(post, user, "Muy aburrido");

            var comment = post.GetComments().Single();

            Assert.That(comment.User.Name, Is.EqualTo("Mariano"));
            Assert.That(comment.Text, Is.EqualTo("Muy aburrido"));
        }
    }
}
