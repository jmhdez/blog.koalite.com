﻿open System
open System.Diagnostics
open canopy
open runner

// Levantamos el servidor
let server = Process.Start(@"c:\Program Files\nodejs\node.exe", @"d:\desarrollo\git\nodejs-sample\app.js")

// Abrimos un browser
start firefox

// Definimos todos los tests
MegaFacts.all()

// Y los ejecutamos
run()

// Cerramos el browser
quit firefox

// Paramos el servidor
server.Kill();



Console.WriteLine "Test finalizados. Pulsa <ENTER> pasa salir."
let exit = Console.ReadLine()