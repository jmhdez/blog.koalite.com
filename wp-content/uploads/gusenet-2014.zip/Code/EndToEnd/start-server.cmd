@echo off
"c:\Program Files\nodejs\node.exe" "d:\desarrollo\git\nodejs-sample\app.js"