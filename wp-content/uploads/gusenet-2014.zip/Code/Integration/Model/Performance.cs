namespace Integration.Model
{
    public class Performance
    {
        public virtual int Id { get; set; }
        public virtual Movie Movie { get; set; }
        public virtual Person Actor { get; set; }
        public virtual string Role { get; set; }
    }
}