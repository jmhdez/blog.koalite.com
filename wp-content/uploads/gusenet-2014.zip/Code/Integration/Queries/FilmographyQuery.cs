﻿using System.Collections.Generic;
using NHibernate;
using NHibernate.Transform;

namespace Integration.Queries
{
    public class FilmographyQuery : IQuery<IEnumerable<FilmographyQuery.Result>>
    {
        private readonly string actorName;

        public FilmographyQuery(string actorName)
        {
            this.actorName = actorName;
        }

        public IEnumerable<Result> Execute(ISession session)
        {
            const string sql = @"
select 
    m.Title as Movie,
    m.Year as Year,
    p.Role as Role
from 
    Movie m 
    inner join Performance p on m.Id = p.Movie_Id
    inner join Person a on p.Actor_Id = a.Id
where
    a.Name = :actor
";

            return session.CreateSQLQuery(sql)
                .SetParameter("actor", actorName)
                .SetResultTransformer(Transformers.AliasToBean<Result>())
                .List<Result>();
        }

        public class Result
        {
            public string Movie { get; set; }
            public int Year { get; set; }
            public string Role { get; set; }
        }
    }
}
