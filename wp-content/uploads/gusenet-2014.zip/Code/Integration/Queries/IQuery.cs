using NHibernate;

namespace Integration.Queries
{
    public interface IQuery<out T>
    {
        T Execute(ISession session);
    }
}