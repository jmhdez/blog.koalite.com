﻿using System;
using System.Data.SqlClient;
using FluentNHibernate.Automapping;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using Integration.Model;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using Environment = NHibernate.Cfg.Environment;

namespace Integration
{
    public class DBTools
    {
        private static readonly Lazy<Configuration> Configuration = 
            new Lazy<Configuration>(BuildConfig);

        public static readonly Lazy<ISessionFactory> SessionFactory = 
            new Lazy<ISessionFactory>(() => Configuration.Value.BuildSessionFactory());

        public static void CreateDB()
        {
            CreateEmptyDB();
            AddSchema();
        }

        private static void CreateEmptyDB()
        {
            var connectionString = Configuration.Value.GetProperty(Environment.ConnectionString);

            var connectionStringBuilder = new SqlConnectionStringBuilder(connectionString);

            var dbName = connectionStringBuilder.InitialCatalog;

            connectionStringBuilder.InitialCatalog = "master";
            var masterConnectionString = connectionStringBuilder.ConnectionString;

            using (var conn = new SqlConnection(masterConnectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();

                var sql = @"IF (EXISTS (SELECT name 
                                        FROM sysdatabases 
                                        WHERE '[' + name + ']' = '{0}' OR name = '{0}'))
                            BEGIN
                                DROP DATABASE {0}
                            END
                       
                            CREATE DATABASE {0}";


                // Sí, esto es sensible a SQL-injection, pero ni drop ni create database admiten parámetros
                sql = string.Format(sql, dbName);

                cmd.CommandText = sql;

                cmd.ExecuteNonQuery();                
            }
        }

        private static void AddSchema()
        {
            var schema = new SchemaExport(Configuration.Value);
            schema.Execute(false, true, false);
        }

        private static Configuration BuildConfig()
        {
            return Fluently.Configure()
                .Database(MsSqlConfiguration.MsSql2012
                    .ConnectionString(c => c.Server(@"localhost\SQLExpress")
                        .Database("MovieDB")
                        .TrustedConnection()))
                .Mappings(m => m.AutoMappings.Add(AutoMap.AssemblyOf<Person>(new AutomappingConfiguration())))
                .BuildConfiguration();
        }

        private class AutomappingConfiguration : DefaultAutomappingConfiguration
        {
            public override bool ShouldMap(Type type)
            {
                return type.Namespace == typeof(Person).Namespace;
            }
        }
    }
}