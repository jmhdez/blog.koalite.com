﻿using System;
using System.Linq;
using NHibernate;
using NUnit.Framework;

namespace Integration.Tests
{
    public abstract class DBTestBase
    {
        [TestFixtureSetUp]
        public void GlobalSetup()
        {
            DBTools.CreateDB();
        }

        [SetUp]
        public void Setup()
        {
            DeleteAll("Performance", "Movie", "Person");
        }

        protected ISession CreateSession()
        {
            return DBTools.SessionFactory.Value.OpenSession();
        }

        protected void Tx(Action<ISession> action)
        {
            using (var session = CreateSession())
            using (var tx = session.BeginTransaction())
            {
                action(session);

                tx.Commit();
            }
        }

        protected T Tx<T>(Func<ISession, T> func)
        {
            var result = default(T);

            Tx(s =>
            {
                result = func(s);
            });

            return result;
        }

        protected void DeleteAll(params string[] entities)
        {
            Tx(s =>
            {
                var deletes = entities.Select(x => string.Format("from {0}", x));

                foreach (var delete in deletes)
                    s.Delete(delete);
            });
        }

        protected T Save<T>(T entity)
        {
            return Tx(s =>
            {
                s.Save(entity);
                return entity;
            });
        }
    }
}
