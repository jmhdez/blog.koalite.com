﻿using System;
using System.Collections.Generic;
using System.Linq;
using Integration.Model;
using Integration.Queries;
using NUnit.Framework;

namespace Integration.Tests
{
    [TestFixture]
    public class FilmographyQueryTest : DBTestBase
    {
        [Test]
        public void Returns_Empty_Result_When_There_Are_No_Movies()
        {
            var movies = GetFilmography("Alfredo Landa");

            Assert.That(movies, Is.Empty);
        }

        [Test]
        public void Returns_Performances_Of_Given_Actor()
        {
            var alfredoLanda = AddActor("Alfredo Landa");

            var venteAAlemania = AddMovie("Vente a Alemania, Pepe", 1971);
            var dormirYLigar = AddMovie("Dormir y ligar, todo es empezar", 1974);
            
            AddPerformance(venteAAlemania, alfredoLanda, "Pepe");
            AddPerformance(dormirYLigar, alfredoLanda, "Saturnino");

            var results = GetFilmography("Alfredo Landa").ToArray();

            Assert.That(results.Length, Is.EqualTo(2));

            Assert.That(results.Any(x => x.Movie == "Vente a Alemania, Pepe"));
            Assert.That(results.Any(x => x.Movie == "Dormir y ligar, todo es empezar"));
        }

        [Test]
        public void Does_Not_Return_Movies_Of_Other_Actors()
        {
            AddActor("Alfredo Landa");

            AddMovie("Terminator", 1984);

            var results = GetFilmography("Alfredo Landa").ToArray();

            Assert.That(results, Is.Empty);
        }

        private Performance AddPerformance(Movie movie, Person actor, string role)
        {
            return Save(new Performance { Role = role, Actor = actor, Movie = movie });
        }

        private Person AddActor(string name)
        {
            return Save(new Person {Name = name, BirthDate = new DateTime(1950, 1, 1)});
        }

        private Movie AddMovie(string title, int year)
        {
            return Save(new Movie { Year = year, Title = title });
        }

        private IEnumerable<FilmographyQuery.Result> GetFilmography(string actor)
        {
            using (var session = CreateSession())
                return new FilmographyQuery(actor).Execute(session);
        }
    }
}